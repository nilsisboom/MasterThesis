each data file intro sheet with author, source of data, date of download and whether any modifications were applied

##prices.csv##
Author: International Monetary Fund
Source: https://data.imf.org/?sk=471dddf8-d8a7-499a-81ba-5b332c01f8b9 - All commodity prices in index form have the be selected.
Date of download: 10.09.2023
Modifications: The name was changed to prices.csv

##waste per EWC and treatment.csv##
Author: Eurostat
Source: https://ec.europa.eu/eurostat/databrowser/view/env_wastrt/default/table?lang=en - The entire dataset has to be selected. 
More information about the dataset can be found in my thesis and under https://ec.europa.eu/eurostat/cache/metadata/en/env_wasgt_esms.htm. Each data set is
available as a csv and a csv.gz
Date of download: 19.06.2023
Modifications: The name was changed to waste per EWC and treatment.csv

##WEEE waste 2.csv.gz##
Author: Eurostat
Source: https://ec.europa.eu/eurostat/databrowser/view/env_wastrt/default/table?lang=en - The entire dataset has to be selected. 
More information about the dataset can be found in my thesis and under https://ec.europa.eu/eurostat/cache/metadata/en/env_waselee_esms.htm. Each data set is
available as a csv and a csv.gz
Date of download: 09.09.2023
Modifications: The name was changed to WEEE waste 2.csv.gz

